# B's Southern Creations — handoff (not FlashTrack)

Use this file (or the Notion page) to start a **new Cursor chat** that is only about this brand site.

## Quick start for a new chat

Paste:

```
This chat is ONLY for B's Southern Creations — not FlashTrack.

Project: static marketing site in folder bs-southern-creations/
Branch: cursor/bs-southern-creations-1ab4
PR: https://github.com/Mia-Cran/flashtrack-ai-learning-platform/pull/14

Stack: plain HTML/CSS/JS. Logo in assets/logo.png + mark.png. Products in assets/products/.

Decisions so far:
- Host on Vercel (free)
- Domain for cards: bsoutherncreations.com (GoDaddy domain-only)
- Business card layouts A (centered) vs B (split) — pick later
- Shop: site is marketing-only; selling candidates Big Cartel / Square / Etsy
- No admin CMS yet — edit files or ask Cursor

Please continue from this handoff. Do not mix in FlashTrack work.
```

## Status snapshot

- One-page site: hero, shop, custom, contact; “What we make” dropdown
- Files under `bs-southern-creations/` (currently parked in the FlashTrack repo — move to its own repo when ready)
- Cloudflare tunnels are temporary; permanent host = Vercel
- Domain spelling: **bsoutherncreations.com** (one s after b)

## Preview

```bash
cd bs-southern-creations
python3 -m http.server 5174
```
